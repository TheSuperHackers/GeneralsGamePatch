 Almost Human AI By RVMECH
version1.6
rvmech@cncgames.com

Beta testers:
Carch
ZhaDuM

Special thanks to Simon Platten for the crate idea.
Special thanks to Seebo for the information regarding unloading of transports.


--------------------------------------------------------------------------------------------
Although  you are free to use these scripts I would appreciate it if you would not offer them for download from your site. They were created for the fans and are offered from CNCDEN (http:\\www.cncgames.com)exclusively. I would also appreciate a bit of credit if you employ them in your map. Thanks, RV
---------------------------------------------------------------------------------------------------

                              INSTRUCTIONS FOR MAP MAKERS
If you are making a map and would like to use the AI, you are free to do so, however a nice little acknowledgement would be inorder as I spent a lot of time developing this. 
 I have included a basic flat 4 player map that is setup properly for the AI. This should give you an idea as to how much room is required for the AI to build properly as well as showing you how and where to create the new trigger areas.

To incorporate the AI into your map you will need to add one EXTRA attack path per player, this attack path is named "Special". It is applied in the same manner as the normal attack paths, IE Special1, Special2, Special3, etc. 


You will also have to install two extra Trigger Areas, one is labled "hack" the other is labeled SkirmishWorld. This area is used only by the China hackers. They leave the barracks area and setup in this area. It need not be large as it only needs to hold a few hackers. It should be placed in the rear of the player starting areas and a bit outside the InnerPerimeter. Again it is named in the similar manner as the normal ones, IE hack1, hack2, hack3, etc. In the center of each of these hack areas you will need to place a waypoint. The waypoint is used by the China hackers as a reference point to run too. This allows the Hackers to run towards the waypoint, which is in the center of the hack trigger area, when the first hackers in the team reaches it then he and the others will "setup" and begin hacking. This in effect strings them out a bit verses the normally bunching up that the stock AI does.
The SkirmishWorld trigger area is required to fix a bug that the standard AI has. This will allow tech buildings not placed in the CombatZone to be captured by the AI instead of being ignored. It is also used by this AI inorder to look for and retrieve crates. It SURROUNDS the ENTIRE map.

A map.ini file is also incorporated to place in the map folder. This tells the AI where to place the buildings as well as how many to build.


To install the scripts into the map itself simply make sure that you have included the Skirmish players from the Player list. Next go to the script editor and import them. They will then  be installed. If after installing them you look in the script editor and notice question marks over a few files do not be alarmed, it simply means that a trigger area is missing. Unless it is an 8 player map you will always have a question mark over the "China Hackers" folder.
---------------------------------------------------------------------------------------------------

                             INSTRUCTIONS FOR NON-MAP MAKERS
If you are not a map maker and simply want to use the Almost Human AI, you can do that also. I have included two big files for you to use that will allow you to use either the AHAI or the standard AI. It might appear complicated but it really isn't. Just read and follow  the instructions carefully. 


Step#1 Navigate to the game directory, normally located at C\program Files\EA games\Command and Conquer Generals.
 
Step#2 Open the Folder called Data.
 
Step#3 Open the folder. Inside that one you'll find the folder named "Scripts".

Step#4 Remove the folder to another directory or rename it to "Original Scripts".
 
Step#5 Place the .big file, that came with this download, named "OriginalScripts.big" into your game directory. This file contains all the original skirmish and multiplayer scripts. Only God and EA know why these were not placed in a big file anyway.

Step#6 Navigate to your My Documents\Command and Conquer Generals folder.

step#7 Place the other .big file, that came with this download, named "AHAI.big" into that folder.

Step#8 Place the shortcut named AHAI, that came with this download, on your desktop. If you have another OS other than XP then create another shortcut for the game, rename it AHAI  and enter -mod AHAI.big in the Command line. You can do this by right clicking on the shortcut and choosing "proprties" from the menu. Then enter in the command. When your done it should look like this:

      "C:\Program Files\EA Games\Command and Conquer Generals\generals.exe"  -mod AHAI.big

Notice there is a space bewteen the qoutation mark(") and the minus mark(-).


 TO PLAY THE GAME NORMALLY SIMPLY USE YOUR USUAL SHORTCUT. 

 TO PLAY THE GAME USING THE ALMOST HUMAN AI CLICK ON THE AHAI SHORTCUT.


 It should be noted that this AI is not always compatable with every map. If the building area is too small or the areas around the supply docks is too little then it may decide to build on top of another building or even build in water (yes I have seen that). If you use the AI in an existing map you should also be aware that some of the scripts will be disabled due to the loss of 2 trigger areas, 8 waypoints and 1 extra attack path. But it will still function and remain quite difficult to oppose in the brutal mode. 
--------------------------------------------------------------------------------------------------

The USA  AI will choose from three seperate startegies when the Strat center is built...just as you would. It will also choose from three seperate skillsets, or generals options depending on the points aquired....just as you would. It might decide to use the A-10 thunderbolts or it may decide to employ paratroops. It may even decide to use a combination of both. There is no way to tell until you are on the recieving end.
 It will choose different priorities to attack at random times..just as you would. It may decide to take out your defenses first and then work on your base buildings. It may decide to eliminate your tanks and infantry first then work on your base buildings. It may even just decide to go straight for your throat. No way to know until it happens.
 It also now attacks from four attack paths versus the normal three.
Armored teams now have Comanche air support to protect them from ambush. 
The Usa AI will also choose from three seperate "Generals style" templates.  You may find yourself fighting a general that relies heavily on ground troops and armored vehicles, you may find yourself fighting against a general that believes heavily in air power. The last general you may find yourself up against is a one that likes to employ balance between the ground troops and the air power. ONLY the balanced General will build and use the Particle Cannon Uplink. How will you know which is which?...If you see 8 Raptors, 4 Comanches, and tank division hitting your base then the Air power general is greeting you. If you find that you in the middle of the Mother of all tank wars then you may assume that the Ground General has sent his calling card. If you notice a ION cannon burnimg up your supply building then  the balanced general has come to visit.
The USA AI will also employ the normally unused upgrade available for some of it's units, IE Comanche Rocket Pods and Drone Armor.

The China AI will also choose from three seperate skillsets. It may use Artilley barrages or cash hacks, or a combination of the two. It may use Nuke Cannons or Cluster Bombs...just as you would.
The China AI will also make better use of it's Bunkers, over time it will fill them with tank hunters to augment its base defenses.
The China AI will also use four attack paths verses the normal three.
The China AI will move it's Hackers away from the barracks area and into a relitively safe area in order to steal cash, unlike the normal AI.
The China AI will , like it's counter part the USA, choose from three seperate  templates. One relies heavily on ground power , one relies heavily, very heavily , on air power, and the last one uses a balanced attack. Only the balanced template employs the nuclear silo. Only the AI knows which one it will choose from. 
The China Ai also employs the normally unsed Nuclear Tank upgrade and the Subliminal Messaging upgrade.
Lastly the China AI will employ the use of Cluster mines around it's buildings. There are four Cluster mine templates that it will choose from, all pof the buildings, base buildings, defense structures, or none. You win't know until you get close enough to find out...heheh,  good luck.

The GLA AI also chooses from three seperate skillsets. All three rely on the Rebel Ambush, but combine the Cash Bounty as well as the hijacker upgrades in different levels. The GLA general uses only one template...ground power. However, it uses them quite well. it employs more diversified attacks and uses the Angry Mob to it's advantage during the heat of the battle verses the end when it is almost defeated. The Angry mob is also upgraded to  "Arm the Mob' by 66%. There are also more of them. 
Bomb Trucks will use the biotoxin and high explosive upgrades. They also come at you in groups of no less than two.

All of the AI generals will build their respective bases in a more efficient manner. Base defenses surround the base area. Power plants are located on at least three sides. China will build two propaganda towers in a strategic manner. The GLA will build tunnel networks next to  Stinger Sites to provide added support in fending off assaults from the air and ground combination attacks.

Extra teams have been provided for the extra attack path. All brutal teams have been some what modified to reflect the General that employs them. Some teams are larger than normal some are smaller and some are very diversified inorder to provide for most situations.

This is beta version and I am open to suggestions and tweaks. Feel free to email me and give me your thoughts and suggestions.   



_________________________________________________________________________________________________

                                 Items added sinse version 1.0

#1 All factions will create a team at the start of the game, and only at the start, and look for any crates that are placed on the map. The USA will build up to 3 Humvee's for this purpose, China will build up to three Dragon Tanks, whilst the GLA uses up to three technicals.

#2  A work around was scripted for a bug that appears when the AI uses 3 or more Dozers for either China or the USA. Sometimes the Dozers get thier blades locked up together and can't move forward or backwards. I tried scripting them to move but it appears as though they really are locked up. The solution was to create a timer for each one and ADD time to it as they  completed their duties. If they fail to do the assignments in the allotted time the guilty team is destroyed and another is built to take it's place. This isn't perfect but the game keeps going, whereas before this the AI just stopped until the teams were destroyed by enemy fire.

#3 The Defcon conditions have been reworked so that the AI will now continue to build and attack until it is destroyed or the money runs out on the map.

#4 The AI will expand into another area around a Supply Dock if available room is provided. So when designing the map keep this in mind! It will build an extra War Factory, Barracks, Power Plant and Defensive structures. In addition China will produce another Speaker Tower.
 If more than two supply docks can be procured by the AI it might  also produce another Power Plant or maybe in the Gla 's case another Black Market. In all casess defesive structures will be built.

#5 The GLA Technicals will now be targeted by enemy units when in the CombatZone. The normal AI does not have the Technicals listed in the Defined Objects List, which kept them from being targeted.   

#6 When an opposing player uses a Super weapon the AI's units will no longer stand around and blindly take the hit. As soon as the player uses the weapon any units that remain in the base area will immediatley leave the area and attack with extreme predjudice!

#7 China and the USA Airforces will no longer wait for, or ignore incoming aircraft bearing Super Weapons. They will fly out to meet them and attack, in a robust manner, the oncoming Super Weapon laden plane. The GLA will also activly seek out the airborne supers using the existing Tunnel Defenders and Gattling Tanks in the same robust manner.

#8 If the SkirmishWorld trigger area is installed then the AI will capture Tech Buildings placed anywhere on the map. The standard AI will only capture these when placed in the CombatZone. 

#9 China will now use the Nuke Cannon. Several teams have been scripted to employ these awesome Devices of Doom. They will attack in conjuntion with other units to effectivly decimate the enemy base from the outside  to the inside .....one step at a time. A special Priority base was created exclusivley for them.

#10 Jarmen Kell will roam the Combat Zone seeking prey, thus ensuring that his life is prolonged more so than when he enters blindly into an enemy base area.

#11 Teams have been optimised for a fasterbuild time. Basically smaller teams  being built but being launched at the same time. This keeps the base guarded at all times and allows the AI to recruit emergency teams if need be.

#12 All three modes of skirmish play are available. Brutal: extremely hard to defeat and great fun to oppose. Hard: offers most of the different player templates that the brutal offers with the exception of the USA and China Air power. Normal: for n00bs...nuf said.

#13 Bug in the previous version was repaired that had china building the Speaker tower out of order.

#14 Bug was in the previous version was repaired that had china running out of power before the base was up in some cases.

#15 All teams employing transports have had their "State" changed from aggresive to normal. Aggresive appears to keep them from unloading.

There are a lot of little tweaks and few more bugs that were worked out but I'm damned if I can remember what they were.....-=(


These files have been tested thouroghly, however nothing is perfect. If it blows up your machine and smoke comes pouring out...you still own the machine and don't come back to me for revenge.  So much for the disclaimer.


Thats it, RVMECH